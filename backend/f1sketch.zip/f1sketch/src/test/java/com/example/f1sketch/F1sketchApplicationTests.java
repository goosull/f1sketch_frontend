package com.example.f1sketch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class F1sketchApplicationTests {

	@Test
	void contextLoads() {
	}

}
