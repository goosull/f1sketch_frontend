package com.example.f1sketch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class F1sketchApplication {

	public static void main(String[] args) {
		SpringApplication.run(F1sketchApplication.class, args);
	}

}
